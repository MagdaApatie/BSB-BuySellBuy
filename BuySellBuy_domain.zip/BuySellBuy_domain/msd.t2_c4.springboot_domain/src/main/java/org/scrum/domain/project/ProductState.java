public enum ProductState {
	ACTIV, INACTIV
}
