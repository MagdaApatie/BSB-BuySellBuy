package org.scrum.domain.sprint;

//@Singleton
public class SprintFactory {
	
}
