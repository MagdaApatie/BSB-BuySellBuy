package org.scrum.domain.services;

public interface IAuditingPlanningProjectBusinessWorkflowService {
	void auditProjectFeature(Integer projectId, String featureName);
}
