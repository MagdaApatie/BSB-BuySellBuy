package org.scrum.application.services;

public enum WorkflowAction{
	PLAN_NEW_PROJECT, ADD_FEATURE_TO_PROJECT, PLAN_CURRENT_RELEASE, GET_PROJECT_SUMMARY_DATA;
}
