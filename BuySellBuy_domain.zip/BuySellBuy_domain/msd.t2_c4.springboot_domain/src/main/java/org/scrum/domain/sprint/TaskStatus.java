package org.scrum.domain.sprint;

public enum TaskStatus{
	IN_PROGRESS, BLOCKED, COMPLETE, SUSPENDED;
}