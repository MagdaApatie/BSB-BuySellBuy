package org.scrum.domain.sprint;

public enum TaskCategory{
	ANALYSIS, DESIGN, IMPLEMENTATION, TEST;
}