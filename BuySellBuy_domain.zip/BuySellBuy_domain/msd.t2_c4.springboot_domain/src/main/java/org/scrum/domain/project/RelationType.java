public enum RelationType {
	CUSTOMER, SUPPLIER
}
